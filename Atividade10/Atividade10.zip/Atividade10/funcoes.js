// funcoes.js

// Função para encontrar o maior número entre três
function encontrarMaior(num1, num2, num3) {
    return Math.max(num1, num2, num3);
}

// Função para ordenar três números em ordem crescente
function ordenarCrescente(num1, num2, num3) {
    const numeros = [num1, num2, num3];
    numeros.sort((a, b) => a - b);
    return numeros;
}
