class Conta {

    constructor(nomeCorrentista, banco, numeroConta, saldo) {

        this.nomeCorrentista = nomeCorrentista;

        this.banco = banco;

        this.numeroConta = numeroConta;

        this.saldo = saldo;

    }

    getDadosConta() {

        return `Nome do Correntista: ${this.nomeCorrentista}\nBanco: ${this.banco}\nNúmero da Conta: ${this.numeroConta}\nSaldo: ${this.saldo}`;

    }

}

class CorrenteComSaldoEspecial extends Conta {

    constructor(nomeCorrentista, banco, numeroConta, saldo, saldoEspecial) {

        super(nomeCorrentista, banco, numeroConta, saldo);

        this.saldoEspecial = saldoEspecial;

    }

    getDadosConta() {

        return `${super.getDadosConta()}\nSaldo Especial: ${this.saldoEspecial}`;

    }

}
class PoupancaComJurosDataVencimento extends Conta {

    constructor(nomeCorrentista, banco, numeroConta, saldo, taxaJuros, dataVencimento) {

        super(nomeCorrentista, banco, numeroConta, saldo);

        this.taxaJuros = taxaJuros;

        this.dataVencimento = dataVencimento;

    }

    getDadosConta() {

        return `${super.getDadosConta()}\nTaxa de Juros: ${this.taxaJuros}%\nData de Vencimento: ${this.dataVencimento}`;
    }
}

function exibirDadosConta() {

    const contaCorrente = new CorrenteComSaldoEspecial("João", "Banco A", "12345", 1000, 500);

    const contaPoupanca = new PoupancaComJurosDataVencimento("Maria", "Banco B", "67890", 2000, 2, "01/12/2023");

    alert("Conta Corrente com Saldo Especial:\n" + contaCorrente.getDadosConta());

    alert("Conta Poupança com Juros e Data de Vencimento:\n" + contaPoupanca.getDadosConta());

}