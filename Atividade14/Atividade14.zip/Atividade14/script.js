function transformarTexto() {
    const inputTexto = document.getElementById('inputTexto').value;
    let textoTransformado = inputTexto;

    if (document.getElementById('checkboxMaiusculas').checked) {
        textoTransformado = textoTransformado.toUpperCase();
    }

    if (document.getElementById('checkboxMinusculas').checked) {
        textoTransformado = textoTransformado.toLowerCase();
    }

    document.getElementById('textoTransformado').textContent = textoTransformado;
}
