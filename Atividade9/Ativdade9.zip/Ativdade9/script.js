const dados = []; 

function calcularResultados() {

  const idade = parseInt(document.getElementById("idade").value);
  const sexo = document.getElementById("sexo").value;
  const opiniao = parseInt(document.getElementById("opiniao").value);

  dados.push({ idade, sexo, opiniao });

  let totalIdade = 0;
  let idadeMaisVelha = 0;
  let idadeMaisNova = Infinity;
  let pessoasPessimo = 0;
  let pessoasOtimoBom = 0;
  let mulheres = 0;
  let homens = 0;

  for (const pessoa of dados) {
    totalIdade += pessoa.idade;

    if (pessoa.idade > idadeMaisVelha) {
      idadeMaisVelha = pessoa.idade;
    }

    if (pessoa.idade < idadeMaisNova) {
      idadeMaisNova = pessoa.idade;
    }

    if (pessoa.opiniao === 1) {
      pessoasPessimo++;
    }

    if (pessoa.opiniao === 3 || pessoa.opiniao === 4) {
      pessoasOtimoBom++;
    }

    if (pessoa.sexo === "feminino") {
      mulheres++;
    } else if (pessoa.sexo === "masculino") {
      homens++;
    }
  }

  const mediaIdade = (totalIdade / dados.length).toFixed(2);

  const porcentagemOtimoBom = (pessoasOtimoBom / dados.length) * 100;

  document.getElementById("mediaIdade").textContent = mediaIdade;
  document.getElementById("idadeMaisVelha").textContent = idadeMaisVelha;
  document.getElementById("idadeMaisNova").textContent = idadeMaisNova;
  document.getElementById("pessoasPessimo").textContent = pessoasPessimo;
  document.getElementById("porcentagemOtimoBom").textContent = porcentagemOtimoBom + "%";
  document.getElementById("mulheres").textContent = mulheres;
  document.getElementById("homens").textContent = homens;
}
