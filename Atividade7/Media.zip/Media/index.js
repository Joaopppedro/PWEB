var nota1 = parseFloat(prompt('Digite a nota 1: '));
var nota2 = parseFloat(prompt('Digite a nota 2: '));
var nota3 = parseFloat(prompt('Digite a nota 3: '));

var media;

function calcularMedia(){
    media = (nota1 + nota2 + nota3) /3;
    return media 
}

media = calcularMedia().toFixed(2);
alert("Sua média é: " + media)
