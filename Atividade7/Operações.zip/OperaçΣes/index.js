var numero1 = parseFloat(prompt('Digite o numero 1: '));
var numero2 = parseFloat(prompt('Digite o numero 2: '));

var soma = numero1 + numero2;
var subtracao = numero1 - numero2;
var produto = numero1 * numero2;
var divisao = numero1 / numero2;
var resto = numero1 % numero2;

alert('Soma: ' + soma.toFixed(2));
alert('Subtração: ' + subtracao.toFixed(2));
alert('Produto: ' + produto.toFixed(2));
alert('Divisão: ' + divisao.toFixed(2));
alert('Resto: ' + resto).toFixed(2);


